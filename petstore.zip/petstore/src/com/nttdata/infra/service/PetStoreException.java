package com.nttdata.infra.service;

public class PetStoreException extends Exception {
	
	public PetStoreException(String message,Throwable cause){
		super(message,cause);
	}
	public PetStoreException(String message){
		super(message);
	}
}
