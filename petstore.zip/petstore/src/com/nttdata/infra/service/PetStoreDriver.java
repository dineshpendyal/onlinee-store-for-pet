package com.nttdata.infra.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.nttdata.pet.dbfw.DBFWException;
import com.nttdata.petstore.dao.OrderDAO1;
import com.nttdata.petstore.dao.PetStoreDAOException;
import com.nttdata.petstore.domain.Cart;
import com.nttdata.petstore.domain.CartItem;
import com.nttdata.petstore.domain.Category;
import com.nttdata.petstore.domain.Customer;
import com.nttdata.petstore.domain.Item;
import com.nttdata.petstore.domain.Product;

public class PetStoreDriver {

	@SuppressWarnings("deprecation")
	public static void main(String args[]) throws PetStoreException,
			DBFWException, Exception, NullPointerException {
		int in = 0;
		int year = 0, month = 0, date = 0;
		int status = 0;
		
		//String newcustid=null;
		Scanner sc = new Scanner(System.in);
		do {
			System.out
					.println("<--<<<<<<<<<<<<<<<<<<<<<<<<<<< PET STORE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			System.out.println("ENTER 1. FOR NEW USER");
			System.out.println("ENTER 2. FOR EXISTING USER");
			in = sc.nextInt();

			switch (in) {
			case 1:
				int result = 0;
				System.out.println("PASSWORD");
				String Password = sc.next();

				System.out.println("ENTER FIRSTNAME");
				String firstName = sc.next();

				System.out.println("ENTER LASTTNAME");
				String lastName = sc.next();

				System.out.println("ENTER DATE OF BIRTH");
				int dateOfBirth = sc.nextInt();

				System.out.println("ENTER ADDRESS");
				String Address = sc.next();

				System.out.println("ENTER CONTACT NUMBERr");
				int contactNumber = sc.nextInt();

				System.out.println("ENTER CREDIT CARD NO");
				int creditCardno = sc.nextInt();

				System.out.println("ENTER CREDIT CARD TYPE");
				String cardType = sc.next();

				System.out.println("ENTER CARD EXPIRY DATE");

				int cardExpiryDate = sc.nextInt();

				Customer cust1 = new Customer();
				cust1.setPassword(Password);
				cust1.setFirstName(firstName);
				cust1.setLastName(lastName);
				cust1.setDateOfBirth(dateOfBirth);
				cust1.setContactNumber(contactNumber);
				cust1.setCreditCardno(creditCardno);
				cust1.setCardType(cardType);
				cust1.setCardExpiryDate(cardExpiryDate);
				cust1.setAddress(Address);

				
				
				PetStoreFacade pf = new PetStoreFacade();

			pf.registerUser(cust1);
				
			  //  String Custid="0";
				
			
			//	cust1.setCustId(newcustid);
				
				System.out.println("customerrrrrrrr "+cust1.getCustId());
				
				
				String id=cust1.getCustId();
				System.out.println("!!!!!! REGISTRATION SUCCESSFUL !!!!!");
				System.out.println("###########   WELCOME  ########");
				System.out.println("YOUR ID= " + id);
				
				
				System.out.println("-----------------------------------");
				
				PetStoreDriver psd = new PetStoreDriver();
				PetStoreDriver.DisplayProducts(id);

				System.out.println("enter 0 to logout");
				sc.nextInt();
				System.out.println("************ THANKYOU ***********");

				break;

			case 2:

				System.out.println("ENTER ID");
				String Cid = sc.next();
				System.out.println("Enter PASSWORD");
				String password1 = sc.next();
				Boolean res=false;
				// new Customer();
				
				PetStoreFacade pfa = new PetStoreFacade();
			
				 res = pfa.validateUser(Cid, password1);
				
				if (res == true) {

					System.out
							.println("||||||||||||||      Logged in successful|y        ||||||||||||||||||");
					PetStoreDriver psd1 = new PetStoreDriver();
					psd1.DisplayProducts(Cid);
					// Display available products

				} else {

					System.out
							.println("Invalid username and password login failed");
				}

			default:
				System.out
						.println("-------------TRY TO ENTER VALID OPTIONS---------");
				break;
			}
		} while (!(status == 0));
	}

//	@SuppressWarnings("unchecked")
	private static void DisplayProducts(String id) throws Exception,
			PetStoreException, PetStoreDAOException, Exception, DBFWException,
			NullPointerException {

		// static OrderDAO1 o = new OrderDAO1();
		PetStoreFacade psf = new PetStoreFacade();
		int itemprice = 0;
		int purchase = 0;
		int finalprice = 0;
		String iname=null;
		String idesc=null;
		int iprice=0;
		int itemid=0;
		do {
			Item i = new Item();
			Scanner sc = new Scanner(System.in);
			Customer customer = new Customer();
			// String idd;
			//System.out.println("Your Customer Id is \t" +);
			System.out
					.println("Category id \t Category Name \t \tCategory Description");
			List<Category> categories = new ArrayList<Category>();
			categories = psf.getCategories();
			for (Category category : categories) {

				System.out.println(category.getCategoryId() + "\t\t\t"
						+ category.getCategoryName() + "\t\t\t"
						+ category.getCategoryDescription());
			}
			System.out.println("Enter the category Id ");
			int categoryId = sc.nextInt();
			i.setCategoryId(categoryId);
			List<Product> pro = new ArrayList<Product>();
			pro = psf.getProductList(categoryId);
			if (!pro.isEmpty()) {
				System.out.println("CategoryId\t ProductId\t \t"
						+ "Description\t\t\tName");
				for (Product pr : pro) {
					System.out.println(pr.getCategoryId() + "\t\t"
							+ pr.getProductId() + "\t\t\t"
							+ pr.getProductDescription() + "\t\t\t"
							+ pr.getProductName() + "\t\t\t");
				}
				System.out.println("Enter the product id ");
				int pid = sc.nextInt();
				i.setProductId(pid);
				List<Item> it = new ArrayList<Item>();
				it = psf.getItemList(categoryId, pid);
				if (!it.isEmpty()) {

					System.out
							.println(" Item id\t Product id\tCategory Id\t item Name\t\t Description \t Price \t ");
					for (Item its : it) 
					{
						System.out.println(its.getItemId() + "\t\t"
								+ its.getProductId() + "\t\t"
								+ its.getCategoryId() + "\t\t"
								+ its.getItemName() + "\t\t"
								+ its.getItemDescription() + "\t\t"
								+ its.getItemPrice() + "\t \t");
						
						iname=its.getItemName();
						idesc=its.getItemDescription();
						iprice=its.getItemPrice();

					}
				}
				List<Item> it1 = new ArrayList<Item>();
				it1 = psf.getItemList(categoryId, pid);
				for (Item its : it1) {
					itemprice = its.getItemPrice();
					System.out.println(itemprice);//trial
				}
				
				
				System.out.println("Please Enter your itemID of your desired product and quantity required ");
				System.out.println("ITEM ID: ");
				itemid = sc.nextInt();
				System.out.println("QUANTITY: ");
				int qty = sc.nextInt();
				
				
				OrderDAO1 od = new OrderDAO1();
				int price = od.getPrice(itemid);
				int value = 0;
				value += (price * qty);
				System.out.println("The total amount to be paid is: Rs."+ value);
				
				
	//-----------------------------------------ADDING IN CART------------------------------------------------------			
		
				int ODER_ID=psf.generateOrderId();
				System.out.println("YOUR ORDER ID IS : " + ODER_ID);
				Cart c=new Cart();
				c.setCustId(id);
				c.getCustId();
				c.setOrderId(ODER_ID);
			    c.getOrderId();
			    List itemlist=new ArrayList();
			    itemlist.add(id);
			    itemlist.add(itemid);
			    
			   
			    itemlist.add(categoryId);
			    itemlist.add(pid);
			    itemlist.add(iname);
			    itemlist.add(idesc);
			    itemlist.add(iprice);
			    c.setItemDetails((ArrayList) itemlist);
			    c.getItemDetails();
				System.out.println("CUTSOMER "+c.getCustId());
				//psf.placeOrder(c);
				
				System.out.println("INSERTED");
			
				
				/*c.getOrderId();
				System.out.println("orderrrr "+	c.getOrderId());
				*/
			
			/*	String iName=null;
				String iDesc=null;
				int iPrice=0;
				
				for(Item its:it)
				{
					if(itemid==its.getItemId())
					{
						
						iName=its.getItemName();
						iDesc=its.getItemDescription();
						iPrice=its.getItemPrice();
						
						
					}
				}*/
				i.setItemId(itemid); 
				i.setItemName(iname);
				i.setItemDescription(idesc);
				i.setItemPrice(iprice);
				
				
				
				
				
				
				Cart ca=new Cart();
				ca.setCustId(id);
				CartItem ct =ca.AddCartItem(i, qty);
				
				ArrayList<CartItem> det= new ArrayList<CartItem>();
				det.add(ct);
				ca.setItemDetails(det);
				od.placeOrder(ca);
				List<Cart> clist = new ArrayList();
				clist = od.getPurchaseDetails(ca.getOrderId());
					//problem here (item details null)
				Iterator itt = clist.iterator();
				while ( itt.hasNext()) {
					Cart cr = (Cart) itt.next();
					System.out.println("CustomerId: "+ca.getCustId());
					System.out.println("OrderId: "+cr.getOrderId());
					
				//List<CartItem> clist2 = new ArrayList();
					//clist2 = cr.getItemDetails();
					//Iterator itt2 = clist2.iterator();
					//while( itt2.hasNext()) {

						//CartItem ci = (CartItem) itt2.next();
	
//						System.out.println("quantity: "+ci.getQuantity());
//						System.out.println("ItemId : "+ci.getItem().getItemId());
//						System.out.println("CategoryId : "+ci.getItem().getCategoryId());
//						System.out.println("ProductId: "+ci.getItem().getProductId());
						finalprice+=value;
						System.out.println("Your total amount is: "+finalprice);
					
						System.out.println("Press 0 to checkout, press anyother number to buy more products");
						purchase=sc.nextInt();
			
				
		}	
	}
	else 
				System.out.println("Entered category ID does not exist...Try again");
				
		}		
		while (purchase != 0);
	}
}