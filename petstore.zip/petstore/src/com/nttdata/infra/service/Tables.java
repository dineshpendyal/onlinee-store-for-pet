package com.nttdata.infra.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Tables {
	public static void main(String[] args) // throws ClassNotFoundException,
											// SQLException {
	{
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", "TRDB2", "TRDB2");
			Statement st = con.createStatement();
		st.executeQuery("create table CreditCardinfo(CreditCardNo number(16) primary key,CardType varchar(20) not null,ExpiryDate number not null)");
			//st.executeQuery("create table Customer(CustId varchar2(20) primary key,Firstname varchar(45) not null,Lastname varchar(45) not null,DOB number not null,Address VARCHAR2(45),contactno number(10),Creditcardno number,foreign key(Creditcardno) references CreditCard(CreditCardNo))");
			st.executeQuery("create table Categories(Categid number(6) primary key,Categname varchar2(20),Categdesc varchar2(30))");

			st.executeQuery("create table Category_Products(Prodid number(10) primary key,Categid number,Proddesc varchar2(30),Prodname varchar2(30),foreign key(Categid) references Categories(Categid))");
			st.executeQuery("create table Product_Line_items(Itemid number(10) primary key,Prodid number,Categid number(10),itemname varchar2(30),Itemname varchar2(50),Itemdesc varchar2(50),Price number)");
			st.executeQuery("create table Purchase_Details(OrderID number primary key,CustID varchar(45),Itemid number,Prodid number(10),Categid number,Quantity number,foreign key(CustId) references Customer(Custid),foreign key(Itemid)references Product_line_items(ItemId))");
			st.executeQuery("create table User2(CustomerId varchar2(10),Password varchar2(20),foreign key(CustomerId)references Customer(custid))");

			System.out.println("table created");

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
/*package com.nttdata.petstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.nttdata.pet.dbfw.DBFWException;
import com.nttdata.pet.dbfw.DBHelper;
import com.nttdata.pet.dbfw.ParamMapper;
import com.nttdata.pet.dbfw.ResultMapper;
import com.nttdata.pet.domain.ConnectionHolder;
import com.nttdata.pet.domain.DBConnectionException;
import com.nttdata.petstore.domain.Customer;

public class UserDAO1 {
	private static ResultMapper CustomerMapper;
	static Logger log = Logger.getLogger(UserDAO1.class);

	public static Customer RegisterUser(final Customer customerObject)throws PetStoreDAOException, DBFWException, DBConnectionException 
    {
		ConnectionHolder ch = null;
		Connection con = null;

		try {
			
			con=ConnectionHolder.getConnection();
			//Customer Id generation
			
			customerObject.setCustId((DBHelper.executeSelect(con, Sqlmapper_pet.FETCHCUSTID2, Sqlmapper_pet.CUSTID )).toString());
			
		
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
			
		} catch (SQLException e1) {
			
			e1.printStackTrace();
			
		}
	
	
		ParamMapper creditcard = new ParamMapper()
		{
			
			public void mapParam(PreparedStatement psmt) throws SQLException {
				
				psmt.setInt(1, customerObject.getCreditCardno());
				psmt.setString(2, customerObject.getCardType());
				psmt.setDate(3, customerObject.getCardExpiryDate());
				
				
			}
		};
		
		
		
		int flag=0;
		//Inserting CreditCard details using mapParam2
		try {
			con=ConnectionHolder.getConnection();
			
			flag=DBHelper.executeUpdate(con, Sqlmapper_pet.INSERTcREDITcARD,creditcard);
		  
		}catch (SQLException e) 
			{
				e.printStackTrace();
		

			final ParamMapper INSERTCUST_p = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					//preStmt.setInt(1, customerObject.getCustId());
					 preStmt.setString(1, customerObject.getCustId());
					 preStmt.setString(2, customerObject.getFirstName());
					 preStmt.setString(3,customerObject.getLastName());
					 preStmt.setDate(4,customerObject.getDateOfBirth());
					 preStmt.setString(5, customerObject.getAddress());
					 preStmt.setInt(6, customerObject.getContactNumber());
					 preStmt.setInt(7, customerObject.getCreditCardno());
				   }

				public void mapParam1(PreparedStatement preStmt) throws SQLException {
//					// TODO Auto-generated method stub
					
				}
			};ParamMapper insertcust= new ParamMapper()
			{
				public void mapParam(PreparedStatement psmt) throws SQLException {
					
					psmt.setString(1, customerObject.getCustId());
					psmt.setString(2, customerObject.getPassword());
				}
			};
			
			
			int result=0;
			
			//Inserting into Customer Table using mapParam
			try {
				con=ConnectionHolder.getConnection();
			result = DBHelper.executeUpdate(con, Sqlmapper_pet.INSERTCUST,insertcust);
			
		
	
		
    } 
	catch (DBFWException E)
	{
		// TODO Auto-generated catch block
		E.printStackTrace();
	} 
	catch (DBConnectionException E) 
	{
		// TODO Auto-generated catch block
		E.printStackTrace();
	}
catch (SQLException e1) {
			
			e1.printStackTrace();
			
		}int result1=0;
			try {	
				
				con=ConnectionHolder.getConnection();
				result1=DBHelper.executeUpdate(con, Sqlmapper_pet.INSERTUSER2, insertcust);		
			    
			} catch (ClassNotFoundException e1) {
				
				e1.printStackTrace();
			
			}catch (SQLException e1) {
				
				e1.printStackTrace();
				
			}finally{
				return customerObject;
			}
			}
	//------------------------------------------------------	
		
		
			public boolean validateUser(final String userId,final String password)throws PetStoreException
			{
					
					Connection con1= null;
					Boolean result=false;
					
					
					//Anonymous class for validating userid and password
					ParamMapper mapParam= new ParamMapper()
					{
						public void mapParam(PreparedStatement psmt) throws SQLException {
							// TODO Auto-generated method stub
							psmt.setString(1, userId);
							psmt.setString(2, passwd);
					}
				    };
				    
					try {
						
						con1=ConnectionHolder.getConnection();
						
						result = DBHelper.executeSelect(con1,Sqlmapper_pet.FETCHCUSTID, Sqlmapper_pet.MAP_USER);
						
						
					
					} catch (ClassNotFoundException e1) {
						
						e1.printStackTrace();
						
					} catch (SQLException e1) {
						
						e1.printStackTrace();
						
					}
					
					finally
					{
						try {
							con1.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					if(data.isEmpty()){
						return false;
					}
					else{
						return true;
					}
					
					
					
				}
				
		
    }
	// ----------------------------------------------------------------------------------------------------------

	
	 * public boolean validateUser(int userId, String password) throws
	 * PetStoreDAOException, DBFWException, DBConnectionException,Exception {
	 * 
	 * }
	 

}
*/