package com.nttdata.infra.service;

import java.sql.SQLException;
import java.util.List;

import com.nttdata.pet.dbfw.DBFWException;
import com.nttdata.pet.domain.DBConnectionException;

import com.nttdata.petstore.dao.OrderDAO1;
import com.nttdata.petstore.dao.PetStoreDAOException;
import com.nttdata.petstore.dao.ProductDAO;

import com.nttdata.petstore.dao.UserDAO1;
import com.nttdata.petstore.domain.Cart;
import com.nttdata.petstore.domain.Category;
import com.nttdata.petstore.domain.Customer;
import com.nttdata.petstore.domain.Item;
import com.nttdata.petstore.domain.Product;

public class PetStoreFacade {

	public boolean validateUser(String id, String password)
			throws PetStoreDAOException, Exception {
		UserDAO1 U = new UserDAO1();
		boolean a = false;
		a = U.validateUser(id,password);
		return a;
	}

	public String registerUser(Customer customerObject)
			throws PetStoreException, Exception {
		// UserADO u= new UserADO();
		//Customer a=new Customer();
			String a = UserDAO1.RegisterUser(customerObject);// no need of object coz this
													// methos is static
		return a;//
	}

	public List<Category> getCategories() throws PetStoreDAOException,
			DBFWException, DBConnectionException, SQLException {
		ProductDAO P = new ProductDAO();
		List<Category> a = P.getCategories();
		return a;

	}

	public List<Product> getProductList(int categId) throws Exception {
		ProductDAO P = new ProductDAO();
		List<Product> a = P.getProductList(categId);
		return a;
	}

	public List<Item> getItemList(int categid, int prodid)
			throws Exception {
		ProductDAO P = new ProductDAO();
		List<Item> a = P.getItemList(categid, prodid);
		return a;
	}

	public List<Category> getCatById(int categid) throws Exception {

		ProductDAO P = new ProductDAO();
		List<Category> a = P.getCatById(categid);
		return a;
	}

	public List<Product> getProduct(int categid, int proid)
			throws Exception {
		ProductDAO P = new ProductDAO();
		List<Product> a = P.getProduct(categid, proid);
		return a;
	}

	public List<Item> getItem(int categid, int ProdId, int ItemId)
			throws Exception {
		ProductDAO P = new ProductDAO();
		List<Item> a = P.getItem(categid, ProdId, ItemId);
		return a;
	}

	public Object placeOrder(Cart shoppingCart) throws Exception {
		OrderDAO1 O = new OrderDAO1();
		Cart a=null;
		a =  (Cart) O.placeOrder(shoppingCart);
		return a;
	}

	public int generateOrderId() throws Exception
	{
		OrderDAO1 O = new OrderDAO1();
		int seq_orderid=O.generateOrderId();
		return seq_orderid;
	}
	
	
	
	
	public Object getPurchaseDetails(int orderId) throws PetStoreDAOException,
			DBFWException, DBConnectionException, SQLException {

		OrderDAO1 O = new OrderDAO1();
		Object a = null;
		a = O.getPurchaseDetails(orderId);
		return a;

	}
}
