package com.nttdata.pet.dbfw;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultMapper {
	public Object mapRow(ResultSet rs) throws SQLException;

	public void mapParam(PreparedStatement preStmt);
}
