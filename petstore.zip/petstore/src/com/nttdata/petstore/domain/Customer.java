package com.nttdata.petstore.domain;



public class Customer {
private String custId;
private String Password;
private String firstName;
private String lastName;
private int dateOfBirth;
private String Address;
private int contactNumber;
private int creditCardno;
private String cardType;
private int cardExpiryDate;


public String getCustId() {
	return custId;
}
public void setCustId(String custid) {
	this.custId = custid;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public int getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(int dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public int getContactNumber() {
	return contactNumber;
}
public void setContactNumber(int contactNumber) {
	this.contactNumber = contactNumber;
}
public int getCreditCardno() {
	return creditCardno;
}
public void setCreditCardno(int creditCardno) {
	this.creditCardno = creditCardno;
}
public String getCardType() {
	return cardType;
}
public void setCardType(String cardType) {
	this.cardType = cardType;
}
public int getCardExpiryDate() {
	return cardExpiryDate;
}
public int setCardExpiryDate(int cardExpiryDate) {
	return this.cardExpiryDate = cardExpiryDate;
}

}
