package com.nttdata.petstore.domain;

public class CartItem {
private Item item;
private int Quantity;
public CartItem(Item obj, int qty)
{
	this.item = item;
Quantity = qty;
	// TODO Auto-generated constructor stub
}
public CartItem() 
{
	
	// TODO Auto-generated constructor stub
}
public Item getItem()
{
	Item i=new Item();
	i.getItemId();
	i.getCategoryId();
	i.getProductId();
	i.getItemDescription();
	i.getItemName();
	i.getItemPrice();
	return i;
}
public void setItem(Item i)
{    
	//Item i=new Item();
	this.item = i;
}
public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}

}
