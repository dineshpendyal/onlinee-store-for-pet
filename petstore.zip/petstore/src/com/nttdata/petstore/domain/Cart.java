package com.nttdata.petstore.domain;

import java.util.ArrayList;
import java.util.Iterator;

public class Cart {
	private int orderId;
	private String custId;
	private ArrayList<CartItem> itemDetails;
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public ArrayList<CartItem> getItemDetails() 
	{
		 Cart c=null;
		 Iterator itr=itemDetails.iterator();
		   
		 
		 CartItem cit1=null;
		 System.out.println("myy list ");
		   while(itr.hasNext())
		   {
			   
			   //cit1=(CartItem)itr.next();
			  
			   System.out.println(itr.next());
			  
		   }
		   System.out.println("-----------------------------");
		   
		  /* System.out.println("	  cit1.getItem()  "+	   cit1.getItem());
	System.out.println("cit1.getQuantity();         "+cit1.getQuantity());*/
		
		
		 
			System.out.println("INSERTED IN ITEM DETAILS LIST");
		
		
		return itemDetails;
	}
	public void setItemDetails(ArrayList<CartItem> itemDetails)
	{
		this.itemDetails = itemDetails;
	}

public  CartItem AddCartItem(Item obj,int qty)
{
	
  // Item obj=new Item();
	
	CartItem cit=new CartItem();
	
	CartItem cit2=new CartItem(obj,qty);
	CartItem cit1=null;
	Item i=new Item();
	
	obj.setItemId(obj.getItemId());
	obj.getItemId();
	System.out.println("checkkk  "+obj.getItemId());
	cit.setQuantity(qty);
	//System.out.println("string obj "+obj.toString());
	System.out.println(obj+" "+qty);
	System.out.println(obj.getItemId());
	i.setItemId(obj.getItemId());
	i.setProductId(obj.getProductId());
	i.setCategoryId(obj.getCategoryId());
	i.setItemDescription(obj.getItemDescription());
	i.setItemName(obj.getItemName());
	i.setItemPrice(obj.getItemPrice());
	cit.setItem(i);
	System.out.println("cit             "+cit.getItem());
	
	
	cit.getItem().getItemId();
	cit.getItem().getProductId();
	cit.getItem().getCategoryId();
	cit.getItem().getItemName();
	cit.getItem().getItemDescription();
	cit.getItem().getItemPrice();
	cit.getQuantity();
	/*Iterator itr=itemDetails.iterator();
	   
	   while(itr.hasNext())
	   {
		   
		   cit1=(CartItem)itr.next();
		   System.out.println("myy list ");
		   System.out.println(itr.next());
		   System.out.println("-----------------------------");
		   
	   }
	
	   System.out.println("	  cit1.getItem()  "+	   cit1.getItem());
System.out.println("cit1.getQuantity();         "+cit1.getQuantity());
	
	
	 
		System.out.println("INSERTED IN ITEM DETAILS LIST");*/
	
	
	itemDetails.add(cit2);
    
	return cit2;
}
}/*c.setItem(obj);
c.setQuantity(qty);
//System.out.println(obj+" "+qty);
itemDetails.add(c);

return c;
}*/
