package com.nttdata.petstore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.log4j.Logger;

import com.nttdata.infra.service.PetStoreException;
import com.nttdata.pet.dbfw.DBFWException;
import com.nttdata.pet.dbfw.DBHelper;
import com.nttdata.pet.dbfw.ParamMapper;
import com.nttdata.pet.domain.ConnectionHolder;
import com.nttdata.pet.domain.DBConnectionException;
import com.nttdata.petstore.domain.Customer;

public class UserDAO1 {
	static Logger log = Logger.getLogger(UserDAO1.class);

	public static String RegisterUser(final Customer customerObject)
			throws PetStoreDAOException, DBFWException, DBConnectionException {

		ConnectionHolder ch = null;
		Connection con = null;
		final String temp = null;
		String autocustid = null;
		List cid = null;
		Boolean result = false;
		List<String> data = new ArrayList<String>();
		int flag = 0, flag1 = 0, flag2 = 0;
		List cidlist = null;
		String clist = null;

		/*
		 * try {
		 * 
		 * 
		 * ch=ConnectionHolder.getInstance(); con=ch.getConnection(); //
		 * psmt.setString(1,customerObject.getCustId());
		 * //psmt.setString(2,customerObject.getPassword());
		 * customerObject.setCustId((DBHelper.executeSelect(con,
		 * SQLMapper.CUSTOMER_ID,SQLMapper.MAP_CUSTID).get(0)).toString());
		 * 
		 * } catch(Exception e) {
		 * 
		 * }
		 */

		// --------------------------------------------------
		try {

			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();

			ParamMapper creditcard = new ParamMapper() // insert credit card
			{

				public void mapParam(PreparedStatement psmt)
						throws SQLException {

					psmt.setInt(1, customerObject.getCreditCardno());
					psmt.setString(2, customerObject.getCardType());
					psmt.setInt(3, customerObject.getCardExpiryDate());

				}
			};
			// customerObject.setCustId((DBHelper.executeSelect(con,
			// SQLMapper.INSERT_CUSTOMER,mapParam2 ).get(0)).toString());
			// System.out.println("hi1");
			flag = DBHelper.executeUpdate(con, SQLMapper.INSERT_CARDDETAILS,
					creditcard);

		} catch (Exception e1) {

			e1.printStackTrace();

		}

		// ---------------------------------------------------------------------------------------------------

		try

		{
			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();

			ParamMapper cust = new ParamMapper() {

				public void mapParam(PreparedStatement psmt)
						throws SQLException {
					// TODO Auto-generated method stub
					// psmt.setString(1, customerObject.getCustId());
					psmt.setString(1, customerObject.getFirstName());
					psmt.setString(2, customerObject.getLastName());
					psmt.setInt(3, customerObject.getDateOfBirth());
					psmt.setString(4, customerObject.getAddress());
					psmt.setLong(5, customerObject.getContactNumber());
					psmt.setInt(6, customerObject.getCreditCardno());
				}
			};

			System.out.println("hi1");
			flag1 = DBHelper
					.executeUpdate(con, SQLMapper.INSERT_CUSTOMER, cust);
			System.out.println("F1" + flag1);
		} catch (Exception e) {

		}

		System.out.println("hi2");
		try // fetch custid
		{
			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();

		}

		catch (Exception e) {

		}

		// ----------------------------------------------------------------------------------

		try {
			String idcus = null;
			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();
			Customer cust = null;

			ParamMapper custid_LIST = new ParamMapper() {

				public void mapParam(PreparedStatement psmt)
						throws SQLException {

				}
			};
			cidlist = DBHelper.executeSelect(con, SQLMapper.CUSTOMER_ID,
					SQLMapper.MAP_CUSTID, custid_LIST);

			java.util.Iterator itr = cidlist.iterator();

			while (itr.hasNext()) {
				cust = (Customer) itr.next();
			}

			idcus = cust.getCustId();
			customerObject.setCustId(idcus);
			/*
			 * cust.setCustId(idcus); customerObject.setCustId(idcus);
			 * 
			 * 
			 * System.out.println("cus class id " + idcus);
			 * System.out.println("C ID LIST "+ cust.getCustId());
			 * System.out.println("CUSTOMER_OBJEC" +customerObject.getCustId());
			 */

			ParamMapper user1 = new ParamMapper() {
				public void mapParam(PreparedStatement psmt)
						throws SQLException {

					psmt.setString(1, customerObject.getCustId());
					psmt.setString(2, customerObject.getPassword());

				}
			};
			System.out.println("useriddddddd" + customerObject.getCustId());

			flag2 = DBHelper.executeUpdate(con, SQLMapper.INSERT_USER, user1);

			System.out.println("sucessssssss!!!" + flag2);

		} catch (Exception e) {
			System.out.println(e);
		}
		// /--------------------------------------------------------

		System.out.println("check!!!!");

		return autocustid;
	}

	// ------------------------------------------------------------------------------------

	// ------------------------------------------------------

	public boolean validateUser(final String id, final String password)
			throws PetStoreException, NullPointerException 
			{
		ConnectionHolder ch=null;
		Connection con= null;
		Boolean result = false;
		List data = new ArrayList();
try{
	ch=ConnectionHolder.getInstance();
	con=ConnectionHolder.getConnection();
		
		
		
		
		ParamMapper valid = new ParamMapper() // insert credit card
		{

			public void mapParam(PreparedStatement psmt)
					throws SQLException
					{
				psmt.setString(1, id);
				psmt.setString(2, password);	
			}

		} ;
		data = DBHelper.executeSelect(con, SQLMapper.VALIDATE_USER,SQLMapper.MAP_USER,valid);
}
catch (Exception e1) 
{
}
if (data.isEmpty())

			result = false;
		else
			result =true;

		return result;

	}
}

// ----------------------------------------------------------------------------------------------------------

