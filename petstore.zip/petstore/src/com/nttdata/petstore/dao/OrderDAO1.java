package com.nttdata.petstore.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.nttdata.pet.dbfw.DBFWException;
import com.nttdata.pet.dbfw.DBHelper;
import com.nttdata.pet.dbfw.ParamMapper;
import com.nttdata.pet.domain.DBConnectionException;
import com.nttdata.pet.domain.ConnectionHolder;
import com.nttdata.petstore.domain.Cart;
import com.nttdata.petstore.domain.CartItem;
import com.nttdata.petstore.domain.Item;

public class OrderDAO1 {

	static Logger log = Logger.getLogger(OrderDAO1.class);

	public int generateOrderId() throws Exception {
		ConnectionHolder ch = null;
		Connection con = null;
		List detail = null;
		int auto_order = 0;
		try {
			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();

			final ParamMapper ODER_ID_MAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement psmt)
						throws SQLException {

				}
			};

			detail = DBHelper.executeSelect(con, SQLMapper.ORDER_ID,
					SQLMapper.MAP_ORDID, ODER_ID_MAPPER);
			System.out.println("orderid   " + detail);
			Cart c = null;

			Iterator itr = detail.iterator();

			while (itr.hasNext()) {
				auto_order = (Integer) itr.next();
			}

		} catch (Exception e) {

		}
		// System.out.println("oder dao " +c.getOrderId());

		return auto_order;

	}

	public Object placeOrder(final Cart shoppingCart) throws Exception {
		ConnectionHolder ch = null;
		Connection con = null;
		/*
		 * int rows=0; final int id; Cart c=null; //Generate orderId and retrive
		 * 
		 * 
		 * 
		 * 
		 * shoppingCart.setOrderId(generateOrderId()); id =
		 * shoppingCart.getOrderId(); List<CartItem> itemids =
		 * shoppingCart.getItemDetails(); final Iterator<CartItem> it =
		 * itemids.iterator(); System.out.println("MY ORDER ID "+ id);
		 * System.out.println(itemids); while (it.hasNext()) { try {
		 * 
		 * 
		 * ch = ConnectionHolder.getInstance(); con = ch.getConnection();
		 * 
		 * ParamMapper mapParam = new ParamMapper() { public void
		 * mapParam(PreparedStatement psmt) throws SQLException {
		 * psmt.setInt(1,id ); psmt.setString(2, shoppingCart.getCustId());
		 * CartItem crt = it.next(); psmt.setInt(3, crt.getItem().getItemId());
		 * psmt.setInt(4, crt.getItem().getProductId()); psmt.setInt(5,
		 * crt.getItem().getCategoryId()); psmt.setInt(6, crt.getQuantity());
		 * 
		 * } }; rows=DBHelper.executeUpdate(con,
		 * SQLMapper.INSERT_PURCHASEDETAIL,mapParam);
		 * System.out.println("ROW "+rows);
		 * System.out.println("SUCCESSFULLY INSERTED HERE !!!! ");
		 * 
		 * Iterator it1 =itemids.iterator();
		 * 
		 * 
		 * while(it1.hasNext()) { c=(Cart)it1.next(); }
		 */

		int rows = 0;
		final Integer id;
		shoppingCart.setOrderId(generateOrderId());
		id = shoppingCart.getOrderId();
		// shoppingCart.AddCartItem(obj, qty);
		List<CartItem> itemids = shoppingCart.getItemDetails();
		final Iterator<CartItem> it = itemids.iterator();
		while (it.hasNext()) {
			try {
				// Connection con = null;

				ch = ConnectionHolder.getInstance();
				con = ConnectionHolder.getConnection();

				ParamMapper mapParam = new ParamMapper() {
					public void mapParam(PreparedStatement psmt)
							throws SQLException {
						// psmt.setInt(1, id);
						psmt.setString(1, shoppingCart.getCustId());
						CartItem crt = it.next();
						psmt.setInt(2, crt.getItem().getItemId());
						psmt.setInt(3, crt.getItem().getProductId());
						psmt.setInt(4, crt.getItem().getCategoryId());
						psmt.setInt(5, crt.getQuantity());

					}
				};
				System.out.println("orderid111  +" + id);
				rows = DBHelper.executeUpdate(con,SQLMapper.INSERT_PURCHASEDETAIL, mapParam);
				
				System.out.println("rowsss             "+rows);
				System.out.println("orderid2222     +" + id);

				System.out.println("inserted succesfully");
			} catch (Exception e) {
				System.out.println(e);
			}

		}
		return rows;
	}

	public List<Cart> getPurchaseDetails(int orderId)
			throws PetStoreDAOException, DBFWException, DBConnectionException,
			SQLException {

		// QUERY TO OBTAIN THE PURCHASE DETAILS FOR THE INCOMING ORDERiD,.
		// RETURN A CART OBJECT CONTAINING DETAILS
		ConnectionHolder ch = null;
		Connection con = null;
		List detail = null;
		try {

			ch = ConnectionHolder.getInstance();
			con = ConnectionHolder.getConnection();

			final ParamMapper fetch_id = new ParamMapper() {

				public void mapParam(PreparedStatement psmt)
						throws SQLException {

					// psmt.setInt(1, shoppingCart.getOrderId());

				}
			};

			detail = DBHelper.executeSelect(con,
					SQLMapper.PURCHASEDETAIL_ORDERID,
					SQLMapper.MAP_PURCHASE_DETAILS, fetch_id);
		} catch (Exception e) {

		}

		return detail;

	}

	public int getPrice(final int itemid) throws SQLException,
			DBConnectionException, DBFWException {
		int price1 = 0;
		ConnectionHolder ch = null;
		Connection con = null;
		List price = null;
		final Item i = new Item();
		Item i1 = null;
		try {
			ch = ConnectionHolder.getInstance();

			con = ConnectionHolder.getConnection();

			final ParamMapper PRICE = new ParamMapper() {

				public void mapParam(PreparedStatement psmt)
						throws SQLException {

					psmt.setInt(1, itemid);
					// System.out.println("proce  "+i.getItemId());
				}
			};

			price = DBHelper.executeSelect(con, SQLMapper.GET_PRICE,
					SQLMapper.MAP_PRICE, PRICE);

			Iterator itr = price.iterator();
			while (itr.hasNext()) {
				i1 = (Item) itr.next();
			}

			price1 = i1.getItemPrice();

			System.out.println(" price" + price1);

		} catch (Exception e) {

		}
		return price1;
	}
}
