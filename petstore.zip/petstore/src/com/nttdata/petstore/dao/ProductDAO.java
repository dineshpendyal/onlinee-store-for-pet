package com.nttdata.petstore.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.nttdata.pet.dbfw.*;
import com.nttdata.pet.domain.*;
import com.nttdata.infra.service.PetStoreException;
import com.nttdata.petstore.domain.Category;
import com.nttdata.petstore.domain.Customer;
import com.nttdata.petstore.domain.Item;
import com.nttdata.petstore.domain.Product;

public class ProductDAO {


		static Logger log=Logger.getLogger(ProductDAO.class);

		//Call from PetStoreFacade getCategories
		public List<Category> getCategories()throws PetStoreDAOException,DBFWException, SQLException, DBConnectionException{
			
			List<Category> data= new ArrayList<Category>(); 
			Connection con= null;
			con=ConnectionHolder.getConnection();
			
			try {
				
				ParamMapper prodet= new ParamMapper()
				{
				
					public void mapParam(PreparedStatement psmt)
							throws SQLException {
						
					}
				};
//				System.out.println("Succesfully Connected to database");

				
				
				data=DBHelper.executeSelect(con, SQLMapper.PRODUCT_CATEGORY, SQLMapper.MAP_CATEGORY,prodet);
				
				
			}  
			catch (Exception e) {
				// TODO Auto-generated catch block
//				System.out.println("is here");
				e.printStackTrace();
				
			}
			finally
			{
				try {
					
					con.close();
				} catch (SQLException e) {
					System.out.println("WErrror is here");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
			return data;
			
		}
		
		
		//No use
		public List<Category> getCatById(final int categId) throws PetStoreDAOException,DBFWException,Exception{
			
			List<Category> data= new ArrayList<Category>(); 
			Connection con= null;
			try {
				con=ConnectionHolder.getConnection();
				ParamMapper mapParam1 = new ParamMapper()
				{
				
					public void mapParam(PreparedStatement psmt)
							throws SQLException {
						psmt.setInt(1, categId);
					}
				};
				data = DBHelper.executeSelect(con, SQLMapper.PRODUCT_PARTICULAR, SQLMapper.MAP_CATEGORY, mapParam1);
			} 
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return data;
		}
		
		
		public List<Product> getProductList(final int categId) throws PetStoreDAOException,DBFWException,Exception{
			
			//Call from PetstoreFacade getProductList
			List data= new ArrayList();
			Connection con =null;
			try {
				try {
					con=ConnectionHolder.getConnection();
//					System.out.println("Successfully connected to database");
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				ParamMapper mapParam2= new ParamMapper()
				{
					
					public void mapParam(PreparedStatement psmt)throws SQLException {
						
						psmt.setInt(1, categId);
						
					}
					
				};
				
				
				try {
					
					data=DBHelper.executeSelect(con, SQLMapper.PRODUCT_LIST_CATEGORY, SQLMapper.MAP_PRODUCT_CATEGORY, mapParam2);
					
				} catch (Exception e) {
					
					e.printStackTrace();
					
				}
				
			}
			finally
			{
				try {
					
					con.close();
					
				} catch (SQLException e) {
					
					e.printStackTrace();
					
				}
			}
			return data;
			
		}
		
		
		//No use
		public List<Product> getProduct(final int categId,final int productId) throws Exception{
			
			List data= new ArrayList();
			Connection con =null;
			try {
				con=ConnectionHolder.getConnection();
				ParamMapper mapParam= new ParamMapper()
				{
					
					public void mapParam(PreparedStatement psmt)
							throws SQLException 
				   {
						psmt.setInt(1, categId);
						psmt.setInt(2, productId);

					}
					
				};
				try {
					data=DBHelper.executeSelect(con, SQLMapper.PARTICULAR_PRODUCT_PROID_CATEGID, SQLMapper.MAP_PRODUCT_CATEGORY, mapParam);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return data;
			
		}
		
		public static List<Item> getItemList(final int productId)throws PetStoreDAOException, DBFWException
		{
			ConnectionHolder ch=null;
			Connection con=null;
			List item=null;
			
			try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
					
					final ParamMapper ITEM_LIST=new ParamMapper()
					{

						@Override
						public void mapParam(PreparedStatement preStmt) throws SQLException {
						preStmt.setInt(1,productId);
//						preStmt.setInt(2, productid);
				
							
						}
						
					};//ananymous class
					
				
				
			item=DBHelper.executeSelect(con,SQLMapper.ITEM_LIST,
					SQLMapper.ITEMMAPPER, ITEM_LIST );
			
				
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {

				try {

					if (con != null)
						con.close();

				} catch (SQLException e) {
				}
			}
			log.info("inserting ItemId ,Item name , Item desc and setting categid and prodid ");
			return item;
		}
		
		
		public List<Item> getItemList(final int categId,final int productId) throws Exception{
			

			List<Item> data= new ArrayList();
			
			Connection con =null;
			try {
				con=ConnectionHolder.getConnection();
				
				//ANN class
				ParamMapper mapParam= new ParamMapper()
				{
					public void mapParam(PreparedStatement psmt)
							throws SQLException 
				   {
						psmt.setInt(1, categId);
						psmt.setInt(2, productId);
						
					}
				};
				
				
				try {
					
					data=DBHelper.executeSelect(con, SQLMapper.PRODUCT_UNIQUE_ITEM, SQLMapper.MAP_ITEMS, mapParam);
					
				      }
				catch (Exception e) 
				{
					e.printStackTrace();
				}
				
			} 
		
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return data;
		}
		
		
		//No use
		public List<Item> getItem(final int categId,final int productId,final int itemId) throws Exception{
			
			List<Item> data= new ArrayList();
			Connection con =null;
			try {
				con=ConnectionHolder.getConnection();
				ParamMapper mapParam= new ParamMapper()
				{
			
					public void mapParam(PreparedStatement psmt)
							throws SQLException
					{
						psmt.setInt(1, categId);
						psmt.setInt(2, productId);
						psmt.setInt(3, itemId);		
					}
				};
				try {
					data=DBHelper.executeSelect(con, SQLMapper.PRODUCT_CATEGID_PRODID_ITEMID, SQLMapper.MAP_ITEMS, mapParam);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return data;
		}
		
		
	}
