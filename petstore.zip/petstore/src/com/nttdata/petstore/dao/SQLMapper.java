package com.nttdata.petstore.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.nttdata.pet.dbfw.ResultMapper;
import com.nttdata.petstore.domain.Cart;
import com.nttdata.petstore.domain.CartItem;
import com.nttdata.petstore.domain.Category;
import com.nttdata.petstore.domain.Customer;
import com.nttdata.petstore.domain.Item;
import com.nttdata.petstore.domain.Product;

public class SQLMapper {

	// Validate user query from table user1
	public static final String VALIDATE_USER = "select * from USER4 where CustId=? and password=? ";

	public static final String ALLUSER = "SELECT * FROM USER2";

	//public static final String USERID = "SELECT * FROM USER4 WHERE CUSTOMERID=?";

	// For customer id from dual and inc
	public static final String CUSTOMER_ID = "select viva.nextval from dual";

	//public static final String FETCHUSERCUSTID = "SELECT viva.nextval FROM dual";
	// Retrive orderId
	public static final String ORDER_ID = "select ORDER_ID.nextval from dual";
	
	//public static final String ORDER_ID = "select ORDER_ID from PURCHASE_DET";

	// Inserting for table Customer
	public static final String INSERT_CUSTOMER = "insert into customer4 values(viva.nextval,?,?,?,?,?,?)";

	// User1 table insertion
	public static final String INSERT_USER = "insert into USER4 values(?,?)";

	// Inserting for Table CreditCard_Info
	public static final String INSERT_CARDDETAILS = "insert into CREDITCARDinfo values(?,?,?)";

	// Displaying product category details
	public static final String PRODUCT_CATEGORY = "select * from Category";

	public static final String PRODUCT_PARTICULAR = "select * from CATEGORy where categid=?";

	// To display products available in certain category
	public static final String PRODUCT_LIST_CATEGORY = "select * from CATEGORY_PRO where categid=?";

	public static final String PARTICULAR_PRODUCT_PROID_CATEGID = "select * from CATEGORY_PRO where categid=? and prodid=?";

	//
	public static final String PRODUCT_UNIQUE_ITEM = "select * from PRODUCT_LINE where categid=? and prodid=?";

	public static final String PRODUCT_CATEGID_PRODID_ITEMID = "select * from PRODUCT_LINe where categid=? and prodid=? and itemid=?"; // Redundant

	// Inserting orders or purchase details to table purchase_details
	public static final String INSERT_PURCHASEDETAIL = "insert into PURCHASE_DET values(?,?,?,?,?)";

	// retrive the purchase details
	public static final String PURCHASEDETAIL_ORDERID = "select * from PURCHASE_DET where orderid=?";

	// Redundant
	public static final String GET_PRICE = "select price from PRODUCT_LINE where itemid=?";

	public static final String ITEM_LIST = " select * from PRODUCT_LINE where prodId=?";

	
	public static final ResultMapper ITEMMAPPER = new ResultMapper() {

		@Override
		public Object mapRow(ResultSet resultSet) throws SQLException {

			Item item = new Item();
			item.setItemId(resultSet.getInt(1));
			item.setProductId(resultSet.getInt(2));
			item.setCategoryId(resultSet.getInt(3));
			item.setItemName(resultSet.getString(4));
			item.setItemDescription(resultSet.getString(5));
			item.setItemPrice(resultSet.getInt(6));
			return item;

		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}

	};

	public static final ResultMapper ALLUSERMAPPER = new ResultMapper() {

		public Object mapRow(ResultSet rs) throws SQLException {
			String custInt = rs.getString(1);
			String Password = rs.getString(2);
			String firstName = rs.getString(3);
			String lastrName = rs.getString(4);
			int dateOfBirth = rs.getInt(5);
			String Address = rs.getString(6);
			int contactNumbe = rs.getInt(7);
			String creditCardno = rs.getString(8);
			String cardType = rs.getString(9);
			//@SuppressWarnings("unused")
			int cardExpiryDate = rs.getInt(10);
			Customer cust1 = new Customer();

			// Customer customerObject= new
			// Customer(custId,Password,firstName,lastName,dateOfBirth,Address,contactNumber,creditCardno,cardType,cardExpiryDate);
			return cust1;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper CUSTLIST = new ResultMapper() {
		public Object mapRow(ResultSet rs) throws SQLException {
			Customer c = new Customer();
			String custid = rs.getString(1);
           
			return c;
		}

		@Override
		public void mapParam(PreparedStatement preStmt)

		{
			// TODO Auto-generated method stub

		}

	};

	public static final ResultMapper MAP_USER = new ResultMapper() {
		public Object mapRow(ResultSet resultSet) throws SQLException {
			// TODO Auto-generated method stub
			Customer customer = new Customer();
			// Customer customer = new Customer(null,null);
			customer.setCustId(resultSet.getString(1));
			customer.setPassword(resultSet.getString(2));
			return customer;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}

	};

	
	
	public static final ResultMapper MAP_USERID = new ResultMapper() {
		public Object mapRow(ResultSet resultSet) throws SQLException {
			// TODO Auto-generated method stub
			Customer customer = new Customer();
			// Customer customer = new Customer(null,null);
			customer.setCustId(resultSet.getString(1));
	
			return customer;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}

	};


	
	
	
	
	
	
	
	
	
	
	


	public static final ResultMapper MAP_CATEGORY = new ResultMapper() // Maps
																		// Categories
																		// into
																		// Table
	{
		public Object mapRow(ResultSet resultSet) throws SQLException {

			Category category = new Category();
			category.setCategoryId(resultSet.getInt(1));
			category.setCategoryName(resultSet.getString(2));
			category.setCategoryDescription(resultSet.getString(3));
			return category;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}

	};

	public static final ResultMapper MAP_CUSTID = new ResultMapper() {
		public Object mapRow(ResultSet resultSet) throws SQLException {

			Customer c = new Customer();
			c.setCustId(resultSet.getString(1));
			return c;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper MAP_ORDID = new ResultMapper() {
		
		public Object mapRow(ResultSet resultSet) throws SQLException {
			
			int result = resultSet.getInt(1);
			return result;

		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper MAP_PRODUCT_CATEGORY = new ResultMapper() {

		public Object mapRow(ResultSet resultSet) throws SQLException {

			Product product = new Product();
			product.setCategoryId(resultSet.getInt(2));
			product.setProductId(resultSet.getInt(1));
			product.setProductDescription(resultSet.getString(3));
			product.setProductName(resultSet.getString(4));

			return product;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper MAP_ITEMS = new ResultMapper() {

		public Object mapRow(ResultSet resultSet) throws SQLException {
			Item item = new Item();
			item.setItemId(resultSet.getInt(1));
			item.setProductId(resultSet.getInt(2));
			item.setCategoryId(resultSet.getInt(3));
			item.setItemName(resultSet.getString(4));
			item.setItemDescription(resultSet.getString(5));
			item.setItemPrice(resultSet.getInt(6));
			return item;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper MAP_PRICE = new ResultMapper() {

		public Object mapRow(ResultSet resultSet) throws SQLException {
			Item item = new Item();
			item.setItemPrice(resultSet.getInt("price"));
			
			return item ;
		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};

	public static final ResultMapper MAP_PURCHASE_DETAILS = new ResultMapper() {

		public Object mapRow(ResultSet resultSet) throws SQLException {
			Item i = new Item();
			Cart mapCart = new Cart();
			mapCart.setOrderId(resultSet.getInt("ORDERID"));
			mapCart.setCustId(resultSet.getString("CUSTID"));
			i.setItemId(resultSet.getInt("ITEMID"));
			i.setProductId(resultSet.getInt("PRODID"));
			i.setCategoryId(resultSet.getInt("CATEGID"));
			mapCart.AddCartItem(i, resultSet.getInt("QUANTITY"));

			System.out.println("The order details are ");
			System.out.println();
			return mapCart;

		}

		@Override
		public void mapParam(PreparedStatement preStmt) {
			// TODO Auto-generated method stub

		}
	};
}
